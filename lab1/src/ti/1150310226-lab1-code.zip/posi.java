package ��Ա��;

public class posi {
    private int x;
    private int y;
    public posi(int x,int y) {
    	this.x = x;
    	this.y = y;
    }
    public int get_x() {
    	return x;
    }
    public int get_y() {
    	return y;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
