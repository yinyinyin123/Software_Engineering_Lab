package ��Ա��;

public class node {
    private String word;
    public node(String word){
    	this.word = word;
    }
    public String get_data() {
    	return word;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
